# AI Saathi - Flutter Demo Scaffold

This is a minimal Flutter demo app scaffold for "AI Saathi" — an all-in-one AI companion app idea you requested.  
It demonstrates basic chat UI, speech-to-text, and text-to-speech; and shows how to call an AI backend endpoint.

## What is included
- `lib/main.dart` - main Flutter app (single-file demo)
- `pubspec.yaml` - dependencies list
- `README.md` - this file

## IMPORTANT
- This is a **demo scaffold**. It does NOT contain a working AI backend. Replace the placeholder API URL in `AppState.sendToAI()` with your server that talks to OpenAI or other LLM providers.
- You will need to add your own API key and backend logic. Do not embed secret keys in the mobile app.

## How to build APK locally (requires Flutter installed)
1. Install Flutter: https://flutter.dev/docs/get-started/install
2. From project root run:
   ```
   flutter pub get
   flutter build apk --release
   ```
3. The signed APK will be available at `build/app/outputs/flutter-apk/app-release.apk` (for release build).
4. To run in debug on a connected device:
   ```
   flutter run
   ```

## How to produce an automatic APK via GitHub Actions
You can create a `.github/workflows/android.yml` workflow to build the APK in CI and attach it to releases. (Not included in this scaffold.)

## Recommended next steps I can help with (pick any)
- Implement the backend that proxies to OpenAI (so you can keep API keys secret).
- Add onboarding, parental controls, multi-language/localization.
- Create production-ready Android signing config and GitHub Actions to auto-build APKs.

If you want, I can now:
- Provide the backend server code (Node.js/Express or Python/FastAPI) that you can deploy.
- Add features like offline fallback, content filtering, and role-based UIs for kids and elders.