import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(ChangeNotifierProvider(create: (_) => AppState(), child: MyApp()));
}

class AppState extends ChangeNotifier {
  List<ChatMessage> messages = [];
  bool isListening = false;
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  Future<void> startListening() async {
    bool available = await _speech.initialize();
    if (available) {
      isListening = true;
      _speech.listen(onResult: (val) {
        if (val.finalResult) {
          messages.insert(0, ChatMessage(text: val.recognizedWords, fromUser: true));
          notifyListeners();
          sendToAI(val.recognizedWords);
        }
      });
      notifyListeners();
    }
  }

  Future<void> stopListening() async {
    await _speech.stop();
    isListening = false;
    notifyListeners();
  }

  Future<void> speak(String text) async {
    await _tts.speak(text);
  }

  Future<void> sendToAI(String prompt) async {
    messages.insert(0, ChatMessage(text: "…thinking…", fromUser: false, isLoading: true));
    notifyListeners();

    try {
      // TODO: Replace with your AI provider endpoint and API key.
      // Example: call your server that proxies to OpenAI / local LLM
      final uri = Uri.parse("https://example.com/api/ai"); // <- CHANGE THIS
      final resp = await http.post(uri,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"prompt": prompt}),
      );
      String reply;
      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        reply = data["reply"] ?? "Maaf, mujhe jawab nahi mila.";
      } else {
        reply = "Server error: ${resp.statusCode}";
      }

      // replace loading message
      messages.removeWhere((m) => m.isLoading);
      messages.insert(0, ChatMessage(text: reply, fromUser: false));
      notifyListeners();
      await speak(reply);
    } catch (e) {
      messages.removeWhere((m) => m.isLoading);
      messages.insert(0, ChatMessage(text: "Error: \$e", fromUser: false));
      notifyListeners();
    }
  }

  void sendText(String text) {
    messages.insert(0, ChatMessage(text: text, fromUser: true));
    notifyListeners();
    sendToAI(text);
  }
}

class ChatMessage {
  String text;
  bool fromUser;
  bool isLoading;
  ChatMessage({required this.text, required this.fromUser, this.isLoading=false});
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Saathi (Demo)',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: Text('AI Saathi — Demo')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              padding: EdgeInsets.all(12),
              itemCount: state.messages.length,
              itemBuilder: (context, i) {
                final m = state.messages[i];
                return Align(
                  alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Card(
                    color: m.fromUser ? Colors.indigo[100] : Colors.grey[200],
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: m.isLoading ? Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [CircularProgressIndicator(), SizedBox(width:10), Text('Soch raha hai...')],
                      ) : Text(m.text),
                    ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Row(
              children: [
                IconButton(
                  icon: Icon(state.isListening ? Icons.mic : Icons.mic_none),
                  onPressed: () {
                    if (state.isListening) state.stopListening(); else state.startListening();
                  },
                ),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(hintText: 'Yahan type karein...'),
                    onSubmitted: (v) {
                      if (v.trim().isEmpty) return;
                      state.sendText(v.trim());
                      _controller.clear();
                    },
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    final text = _controller.text.trim();
                    if (text.isEmpty) return;
                    state.sendText(text);
                    _controller.clear();
                  },
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}